classdef getPlotsLib
%     show_strain = 1;
%     show_cavity_radius = 0;
%     show_pressure_field = 1;
%     show_pc_pcrit_p0 = 0;
%     show_p_inf = 0;
%     show_heatmaps = 0;
%     show_concentration_lineplots = 0;
%     show_mass_conservation = 0;

    methods(Static)
        function plot_cavity_radius(t, cavity_radius, param_vec, varargin)
            
            % setting optional parameter values, including parsing for
            % validation. parameters are: 
            % x_lim_end - setting the x_lim end value
            % x_units - setting the units for the x-axis
            default_x_lim_end = t(end);
            default_x_units = 'mins';
            expected_x_units = {'secs','mins','hrs','days'};

            p = inputParser;
            addOptional(p, 'x_lim_end', default_x_lim_end);
            addParameter(p, 'x_units', default_x_units, ...
                @(x) any(validatestring(x,expected_x_units)));
            
            parse(p,varargin{:});
            
            switch p.Results.x_units
                case 'mins'
                    divisor = 60;
                case 'hrs'
                    divisor = 60*60;
                case 'days'
                    divisor = 24*60*60;
                otherwise
                    divisor = 1;
            end
            
            %plotting
            arrayLegend=cell(length(param_vec),1);
            for i = 1:length(param_vec)
                arrayLegend{i} = sprintf('%.0f%%w/w EC',(1-param_vec(i))*100);
            end
            
            figure(1)
            cm = colormap('copper');
            
            [numColors,~] = size(cm);
            cm_divisor = floor(numColors/length(param_vec));
            
            [~, col] = size(cavity_radius);
            
            for i = 1:col
                plot(t(:,i)/divisor, cavity_radius(:,i), 'LineWidth', 4, 'color', cm(cm_divisor*i,:));
                hold on
            end
            x_axis_label = sprintf('Time (%s)', p.Results.x_units);
            xlabel(x_axis_label, 'FontSize', 32)
            ylabel('Cavity Radius (cm)','FontSize', 32)
            set(gca,'FontSize',28)
            legend(arrayLegend)
            xlim([0, p.Results.x_lim_end/divisor])
            
        end
        function plot_concentration_profiles(r, t, tvec, C, param_vec, varargin)
            
            default_group_by = 'parameter';
            default_x_lim_end = r(end);
            default_ind_r_cavity = [];
            expected_group_by = {'parameter','time'};

            p = inputParser;

            addOptional(p, 'x_lim_end', default_x_lim_end);
            addOptional(p, 'ind_r_cavity', default_ind_r_cavity);
            addParameter(p, 'group_by', default_group_by, ...
                @(x) any(validatestring(x,expected_group_by)));
            
            parse(p,varargin{:});
            
            if strcmp(p.Results.group_by,'parameter') == 1
                
                for i = 1:length(param_vec)
                
                    titleLabel = sprintf('%.0f%%w/w EC',(1-param_vec(i))*100);
                    
                    figure(1+i)

                    cm = colormap('copper');
                    
                    [numColors,~] = size(cm);
                    cm_divisor = floor(numColors/length(tvec));
                    
                    conc = C{i};

                    for jj=1:length(tvec)
                        plot(r,conc(tvec(jj),:),'LineWidth', 4, 'color', cm(cm_divisor*jj,:))
                        hold all
                    end

                    title(titleLabel, 'FontSize', 32, 'FontWeight', 'Bold')
                    ylabel('Ethanol Concentration (normalized)','FontSize',32,'FontWeight','Bold')
                    xlabel('Radius (cm)','FontSize',32,'FontWeight','Bold')
                    set(gca,'FontSize',28)
                    
                    legendLabels = cell(length(tvec),1);
                    for label = 1:length(legendLabels)
                    legendLabels{label} = sprintf('%d mins', t(tvec(label),i)/60);
                    end
                    
                    legend(legendLabels)

                    xlim([0, p.Results.x_lim_end])
                    ylim([0, 1])

                end
                
            elseif strcmp(p.Results.group_by,'time') == 1
                
                for i = 1:length(tvec)
                    
                    titleLabel = sprintf('%d mins',t(tvec(i),1)/60);
                    
                    figure(1+i)

                    cm = colormap('copper');
                    
                    [numColors,~] = size(cm);
                    cm_divisor = floor(numColors/length(param_vec));
                    

                    for jj=1:length(param_vec)
                        conc = C{jj};
                        plot(r,conc(tvec(i),:),'LineWidth', 4, 'color', cm(cm_divisor*jj,:))
                        hold all
                        if numel(p.Results.ind_r_cavity) > 0
                            ind_r_cavity_at_t = p.Results.ind_r_cavity(tvec(i), jj);
                            plot(r(ind_r_cavity_at_t)*ones(100,1), linspace(0,1, 100), 'LineWidth',2, 'LineStyle', '--', 'color',cm(cm_divisor*jj,:))
                        end
                    end

                    title(titleLabel, 'FontSize', 32, 'FontWeight', 'Bold')
                    ylabel('Ethanol Concentration (normalized)','FontSize',32,'FontWeight','Bold')
                    xlabel('Radius (cm)','FontSize',32,'FontWeight','Bold')
                    set(gca,'FontSize',28)
                    
                    if numel(p.Results.ind_r_cavity) ==  0
                        arrayLegend=cell(length(param_vec),1);
                        for param = 1:length(param_vec)
                            arrayLegend{param} = sprintf('%.0f%%w/w EC',(1-param_vec(param))*100);
                        end
                    else
                        arrayLegend={};
                        for param = 1:length(param_vec)
                            arrayLegend{end+1} =sprintf('%.0f%%w/w EC',(1-param_vec(param))*100);                
                            if param < length(param_vec)
                                arrayLegend{end+1} = '';
                            end
                        end
                        arrayLegend{end+1} = 'Rc';
                    end
                    legend(arrayLegend)
              
                    xlim([0, p.Results.x_lim_end])
                    ylim([0, 1])

                end
                
            end
            
        end
        function plot_velocity(t, tvec, r, ind_r0, v, varargin)
            
            default_x_lim_end = r(end);

            p = inputParser;
            addOptional(p, 'x_lim_end', default_x_lim_end);
            
            parse(p,varargin{:});
            
            figure()
            cm = colormap('copper');
            [numColors,~] = size(cm);
            
            cm_divisor = floor(numColors/length(tvec));

            for i = 1:length(tvec)
                plot(r, v, 'color', cm(i*cm_divisor,:), 'LineWidth', 4)
                hold all
            end
            xlabel('Radius (cm)', 'FontSize', 32)
            ylabel('Velocity (cm/s)','FontSize', 32)
            set(gca,'FontSize',28)
            xlim([0, p.Results.x_lim_end])

            legendLabels = cell(length(tvec)+1,1);
            for label = 1:length(tvec)
                legendLabels{label} = sprintf('%d mins', t(tvec(label))/60);
            end
            
            hold on
            plot(r(ind_r0)*ones(100,1), linspace(min(v),max(v), 100),'LineStyle', '--', 'LineWidth', 2, 'color', [0.3, 0.3, 0.3])
            
            legendLabels{end} = 'r0';
            
            legend(legendLabels)

            
        end
        function plot_pressure()
            
        end
        function plot_strain()
            
        end
    end
end