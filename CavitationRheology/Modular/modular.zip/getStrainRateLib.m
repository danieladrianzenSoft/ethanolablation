classdef getStrainRateLib
    methods(Static)
        function dLdt = velocity_bc_porosity(lambda,Q_needle,E,r0,k_T,phi,theta,a)
            % CONTINUOUS VELOCITY B.C. AT CAVITY BOUNDARY 
            dLdt = ((Q_needle*(1-phi*theta))./(4*pi*(r0^3)*(lambda.^2)));
        end
        function dLdt = velocity_bc(lambda,Q_needle,E,r0,k_T,phi,a)
            % CONTINUOUS VELOCITY B.C. AT CAVITY BOUNDARY 
            dLdt = ((Q_needle*(1-phi))./(4*pi*(r0^3)*(lambda.^2)));
        end
        function dLdt = pressure_bc(lambda,Q_needle,E,r0,k_T,phi,a)
            % CONTINUOUS PRESSURE B.C. AT CAVITY BOUNDARY 
            Pc = E*(5/6-(2./(3*lambda))-(1./(6*(lambda.^4))));
            dLdt = (Q_needle./(4*pi*(r0^3)*(lambda.^2)))-((k_T*Pc*phi./((r0^3).*(lambda.^2))).*(a./((a./(lambda*r0))-1)));
        end

    end
end


