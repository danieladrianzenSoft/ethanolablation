clear
clc

%% DISCRETIZATION PARAMS

t = linspace(0,2*60*60,1201);
Rtot = 5; %in cm, total dimensions of complete analysis
%numr = 1001; %number of spatial steps
dx = 0.005;
r = 0:dx:Rtot; %radial distance from center
numr = numel(r);

%% INJECTION PARAMS

Q_needle = 10/(3600); %1ml/hr converted to ml/sec; -> CHANGE TO 10 ML/HR for humans
L_needle = 31.75/10; %length of 27 gauge needle 1 1/4", or 31.75mm in length, changed here to cm. 
r_needle = 0.2032/(2*10); %nominal inner diameter of 27 gauge needle is 0.2032mm. Here we change to cm. 
%Vol = 0.50; %total injection volume -> CHANGE TO 0.5ML - 2.5ML for humans
Vol = 1;
%t_injection_end = Vol/Q_needle; % BASED ON HUMAN MODELS, WOULD VARY FROM 3 TO 15 MINUTES
additional_drug = 1; % flag to determine if ethanol has been injected with an additional drug or not.
omega = 0.03; %ethyl cellulose concentration relative to EC


%% CHANGING OMEGA (ETHANOL CONCENTRATION)

phiVec = [1; 1-omega; 1-2*omega; 1-4*omega];

%% ETHANOL PARAMS

%D_S = 5*10^(-6); %(cm^2/s)
D_S = 5*10^(-7); %(cm^2/s) TEST
D_C = D_S*5;
C_0 = 1; %normalized concentration of ethanol
P = 1; %partition coefficient between cavity and tissue.
%phi_vec = linspace(0.6,1,length(omegaVec)); %assuming partition coefficient varies with ECE concentration. Higher ECE leads to higher partition.
P_vec = P.*ones(length(phiVec),1); % assuming partition coefficient is the same regardless of ECE concentration, and is = 1.
mu_oh = 1.0995*10^(-3)*1000/100; %cP viscosity ethanol, converted here to Poise. From "Density, viscosity and surface tension of water+ethanol mixtures from 293k to 323k".
mu_wat = 0.8914*10^(-3)*1000/100; %cP viscosity water, converted 

%% DRUG PARAMS

D_Sdrug = 5*10^(-7); %(cm^2/s)
D_Cdrug = D_Sdrug*1.5;
C_0drug = 1; %normalized concentration of ethanol
Pdrug = 1; %partition coefficient between cavity and tissue.


%% HOST PARAMS (+ HYDRAULIC CONDUCTIVITY, DEPENDENT ON DRUG)

E = 10^(4)*10; %elastic modulus of cervical tissue. In pascals, converted to dyn/cm2. From "Mechanical Properties of Female Reproductive Organs and Supporting Connective Tissues: A Review of the Current State of Knowledge"
r0 = r_needle; %inital radius of cavity = needle radius.
K_wat_t = 1*10^(-14)*((100^4)/(10^5)); %hydraulic permeability in (m^4)/(N*s), here converted to cm^4/(dyne*s) = (cm^3 s^2)/g from "Direct Measurement of the Permeability of Human Cervical Tissue
K_oh_t = K_wat_t * mu_oh / mu_wat;
K_drug_t = K_wat_t * mu_oh / mu_wat;
K_oh_c = 3*10^(-8)/mu_oh; % CHECK ON THIS Effect of ethanol on water permeability of controlled release films composed of ethyl
%k = K*(0.001/0.001095); %hydraulic conductivity in cervical tissue. In cm/s. CHANGE THIS. 
a0 = 1; %radius of tumor in cm.
epsilon_t = 0.3; % porosity in tissue

%% CHANGING D_S, EPSILON_C (POROSITY IN CAVITY) AND THETA DUE TO OMEGA
D_Cvec = linspace(1*10^(-5), D_C, length(phiVec)); % assuming diffusion coefficient ranges from value in itself, to value in tissue, and decreases proportionally with ECE conc.
%D_Cvec = D_C * ones(length(phiVec),1); % assuming diffusion coefficient in cavity is the same as in tissue, and independent of ECE conc.
epsilon_c = linspace(0.9, 0.5, length(phiVec)); % porosity in cavity, assuming ranges from value in tissue at min to 0.9 at max, and increases proportionally with ECE conc. 
%epsilon_c = epsilon_t * ones(length(phiVec),1); % porosity in cavity, assuming its the same as that in itssue and independent of ECE conc.
theta = epsilon_c ./ epsilon_t; % ratio porosity in cavity / porosity in tissue
%theta = epsilon_t * ones(length(phiVec),1);
%D_Svec = (D_C / 2) * ones(length(phiVec),1);

%% SOLVER PARAMS

tspan = [0 Vol/Q_needle];
%n_initialcavityradius = find(r>=r0,1);
y0 = 1;
getSparsity = getSparsityLib;
S = sparse(getSparsity.diagonalBand(numr));
S = sparse(S);
opts1 = odeset('Vectorized','on', 'JPattern', S);
%opts1 = odeset('Vectorized','on','JPattern',S);

%% VISUALIZATION PARAMS

show_strain = 1;
show_cavity_radius = 1;
show_pressure_field = 1;
show_velocity_field = 0;
show_pc_pcrit_p0 = 1;
show_p_inf = 1;
show_heatmaps = 1;
show_concentration_lineplots = 1;
show_mass_conservation = 1;

