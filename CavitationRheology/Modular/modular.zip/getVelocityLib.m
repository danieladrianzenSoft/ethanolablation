classdef getVelocityLib
    methods(Static)
         function v = ethanol_velocity_porosity(r, ind_r_cavity, r0, theta, Q_needle)
            % simplified. Analytically, velocity simplifies to Q / (4pi
            % r^2)
            
            v = zeros(length(r),1);
            v(1) = 2 * Q_needle / (pi * r0.^2); %Vmax in pouiseuille law
            v(2:ind_r_cavity) = Q_needle ./ (4 * pi * (r(2:ind_r_cavity).^2));
            v(ind_r_cavity+1:end) = (Q_needle * theta) ./ (4 * pi * (r(ind_r_cavity+1:end).^2));
            
%             v = zeros(length(r),1);
%             v(1:ind_r0) = Q_needle ./ (4 * pi * r0.^2 );
%             v(ind_r0+1:end) = Q_needle ./ (4 * pi * r(ind_r0+1:end).^2 );
            
%             v = zeros(length(r),1);
%             v(1) = Q_needle ./ (4 * pi * r0.^2 );
%             v(2:end) = Q_needle ./ ((4 * pi * r(2:end).^2 ));
            
%             v = Q_needle ./ (4 * pi * r.^2);
         end
         function v = ethanol_velocity_v3(r, ind_r0, r0, Q_needle)
            % simplified. Analytically, velocity simplifies to Q / (4pi
            % r^2)          
            v = zeros(length(r),1);
            v(1) = 2 * Q_needle ./ ( pi * r0.^2 );
            v(2:end) = Q_needle ./ ( 4 * pi * r(2:end).^2 );
%             v = zeros(length(r),1);
%             v(2:end) = Q_needle ./ ((4 * pi * r(2:end).^2 ));
            
%             v = Q_needle ./ (4 * pi * r.^2);
        end
        function v = ethanol_velocity_v2(r, ind_r0, r0, Q_needle)
            % simplified. Analytically, velocity simplifies to Q / (4pi
            % r^2)          
            v = zeros(length(r),1);
            v(1:ind_r0) = Q_needle ./ (4 * pi * r0.^2 );
            v(ind_r0+1:end) = Q_needle ./ (4 * pi * r(ind_r0+1:end).^2 );
%             v = zeros(length(r),1);
%             v(2:end) = Q_needle ./ ((4 * pi * r(2:end).^2 ));
            
%             v = Q_needle ./ (4 * pi * r.^2);
        end
        function v = ethanol_velocity(t, r, ind_r_cavity, r_needle, phi, k_c, k_t, dlambdadt, delP)
            v = zeros(length(r), length(t));
            for timePt = 1:length(t)
                v(1:ind_r_cavity,timePt) = -(k_c/phi) * delP(1:ind_r_cavity,timePt) + r_needle * dlambdadt(timePt);
                v(ind_r_cavity+1:end,timePt) = -(k_t) *delP(ind_r_cavity+1:end,timePt);
            end
        end
    end
end

