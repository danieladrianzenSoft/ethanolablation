
%% PARAMETERS: initializeParams.m

initializeParams

%% IMPORTING REQUIRED FUNCTION LIBRARIES

fastFind = fastFindLib;
getIndices = getIndicesLib;
getSparsity = getSparsityLib;
getStrainRate = getStrainRateLib;
getPressure = getPressureLib;
getPressureGradient = getPressureGradientLib;
getVelocity = getVelocityLib;
getVelocityGradient = getVelocityGradientLib;
getConcentration = getConcentrationLib;
getPlots = getPlotsLib;

%% indices:

ind_t_injection_end = getIndices.getIndInjectionEnd(t, Vol, Q_needle);
ind_r0 = getIndices.getIndNeedleRadius(r, r0);

%% FINDING VELOCITIES AND VELOCITY GRADIENTS

% v_infusion = getVelocity.ethanol_velocity_v2(r, t, ind_r_cavity, ind_r0, r0, Q_needle);
% dvdr_infusion = getVelocityGradient.simple_velocity_gradient(r, ind_r0, r0, Q_needle);
% v_relaxation = getVelocity.ethanol_velocity_v2(r, t, ind_r_cavity, ind_r0, r0, 0);
% dvdr_relaxation = getVelocityGradient.simple_velocity_gradient(r, ind_r0, r0, 0);


%% COMPUTATIONS


%initializing result arrays 
tt = zeros(length(t),length(phiVec));
lambda = zeros(length(t),length(phiVec));
dlambdadt = zeros(length(t),length(phiVec));
cavity_radius = zeros(length(t), length(phiVec));
ind_r_cavity = zeros(length(t), length(phiVec));
Pc = zeros(length(t),length(phiVec));
P0 = zeros(length(t),length(phiVec));
Pinf = zeros(length(t), length(phiVec));
Pcrit = zeros(length(t), length(phiVec));
Stress = zeros(length(t), length(phiVec));
Pfield = cell(length(phiVec),1);

%     Pc = getPressure.p_c(E, lambda);
%     P0 = getPressure.p_0(phi, K_oh_c, Pc, lambda, dlambdadt, Q_needle, r_needle);
%     Pinf = getPressure.p_inf(P0, mu_oh, Q_needle, L_needle, r_needle);
%     Pcrit = getPressure.p_crit(E, lambda);
%     Stress = getPressure.stress(E, lambda);

C = cell(length(phiVec),1);

%building piecewise time vectors depending on injection end
t_injection = t(1 : ind_t_injection_end);
t_relaxation = t(ind_t_injection_end + 1 : end);

% for i = 1:length(omegaVec)
%     
%     IC_oh = zeros(1,numr+1); %Initial condition
%     IC_oh(1) = y0;
%     IC_oh(2:ind_r0) = C_0;
%     
%     [t_temp, y_temp] = ode23s(@(tt,Y) getConcentration.velocity_bc(tt, Y, r, omega(i), Q_needle, r0, D_C, D_S, phi, Rtot, numr, v, dvdr, fastFind), t, IC_oh, opts1);
%     tt(:,i) = t_temp;
%     lambda(:,i) = y_temp(1,:);
% end



for i = 1:length(phiVec)
    
    %getting lambda, dlambda and cavity radius:
    [~,lambda_temp] = ode23s(@(t,lambda) getStrainRate.velocity_bc_porosity(lambda,Q_needle,E,r0,K_oh_t,phiVec(i),theta(i),Rtot), t_injection, y0);
    tt(:,i) = t;
    dlambda_temp = getStrainRate.velocity_bc_porosity(lambda_temp,Q_needle,E,r0,K_oh_t,phiVec(i),Rtot);
    
    dlambdadt(:,i) = [dlambda_temp; zeros(length(t_relaxation),1)];
    lambda(:,i) = [lambda_temp; lambda_temp(end) * ones(length(t_relaxation),1)];
    
    cavity_radius(:,i) = lambda(:,i) .* r0;
    ind_r_cavity(:,i) = getIndices.getIndCavityRadius(t, r, cavity_radius(:,i));

    
    %Initial condition mass transport:
    IC_oh = zeros(1,numr); 
    IC_oh(1:ind_r0) = C_0;
    
    %fitting spline to use in mass transport:
    cavity_radius_spline = spline(t, cavity_radius(:,i));

    %mass transport: 
    tic
    % infusion
    [~, c_temp_injection] = ode23s(@(t_injection,C_injection) getConcentration.velocity_bc_spline_porosity(t_injection, C_injection, r, D_Cvec(i), D_S, P_vec(i), theta(i), r0, Rtot, numr, Q_needle, cavity_radius_spline, fastFind, getVelocity, getVelocityGradient), t_injection, IC_oh, opts1);
    % relaxation
    % t_relaxation-t_injection(end)
    [~, c_temp_relaxation] = ode23s(@(t_relaxation,C_relaxation) getConcentration.velocity_bc_spline_porosity(t_relaxation, C_relaxation, r, D_Cvec(i), D_S, P_vec(i), theta(i), r0, Rtot, numr, 0, cavity_radius_spline, fastFind, getVelocity, getVelocityGradient), t_relaxation, c_temp_injection(end,:), opts1);

    C{i} = [c_temp_injection; c_temp_relaxation];
    toc
    
    %pressures:
    Pc(:,i) = [getPressure.p_c(E, lambda(1:length(t_injection),i)); ...
               zeros(length(t_relaxation),1)];
    P0(:,i) = [getPressure.p_0(phiVec(i), K_oh_c, Pc(1:length(t_injection),i), lambda(1:length(t_injection),i), dlambdadt(1:length(t_injection),i), Q_needle, r_needle); ...
               zeros(length(t_relaxation),1)];
    Pinf(:,i) = [getPressure.p_inf(P0(1:length(t_injection),i), mu_oh, Q_needle, L_needle, r_needle);...
                 zeros(length(t_relaxation),1)];
    Pcrit(:,i) = getPressure.p_crit(E, lambda(:,i));
    Stress(:,i) = [getPressure.stress(E, lambda(1:length(t_injection),i)); ...
                   zeros(length(t_relaxation),1)];
               
%     ind_r_cavity_out_test = zeros(length(t),1);
%     for xx = 1:length(t)
%             cavity_radius_test = ppval(cavity_radius_spline,t(xx));
%             
%             ind_r_cavity_temp = fastFind.binarySearchBin(r,cavity_radius_test);
%             if (ind_r_cavity_temp == -1)
%                 ind_r_cavity_temp = numel(r);
%             end
%             ind_r_cavity_out_test(xx) = ind_r_cavity_temp;
%     end
%         
%     figure(20+i)
%     
%     plot(t, cavity_radius(:,i),'x')
%     hold on
%     plot(t, r(ind_r_cavity_out_test),'LineWidth',2)
%     hold off
end


%% plotting:

tvec=[find(t>=0*60,1) find(t>=2*60,1) find(t>=6*60,1) find(t>=30*60,1) find(t>=60*60,1) find(t>=2*60*60,1)];

if show_cavity_radius == 1
    getPlots.plot_cavity_radius(tt, cavity_radius, phiVec, 'x_lim_end', 12*60)
end
if show_concentration_lineplots == 1
    getPlots.plot_concentration_profiles(r, tt, tvec, C, phiVec, 'group_by', 'time', 'x_lim_end', a0);
end
if show_velocity_field == 1
   getPlots.plot_velocity(t, tvec, r, ind_r0, v_infusion, 'x_lim_end', a0) 
end

%     figure() 
%     plot(t, ppval(cavity_radius_spline,t),'LineWidth',2)
%     hold on
%     plot(t, cavity_radius(:,i),'x')

% show_strain = 1;
% show_cavity_radius = 0;
% show_pressure_field = 1;
% show_velocity_field = 1;
% show_pc_pcrit_p0 = 0;
% show_p_inf = 0;
% show_heatmaps = 0;
% show_concentration_lineplots = 0;
% show_mass_conservation = 0;


