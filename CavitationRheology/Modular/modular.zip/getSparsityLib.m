classdef getSparsityLib
    methods(Static)
         function S = diagonalBandFirstRowFirstCol(numr)
            % diagonal with +1 -1 padding, plus first row
            % and first col, for when calculating
            % lambda simultaneous with concentration.
            totalSize = numr+1;
            e = ones(totalSize,1);
            A = spdiags([e e e],-1:1,totalSize,totalSize);
            S = full(A);
            S(1,1:end) = 1;
            S(1:end,1) = 1;
        end
        function S = diagonalBand_v2(numr)
            totalSize = numr+1;
            e = ones(totalSize,1);
            A = spdiags([e e e],-1:1,totalSize,totalSize);
            S = full(A);
        end
        function S = diagonalBand(numr)
            totalSize = numr;
            e = ones(totalSize,1);
            A = spdiags([e e e],-1:1,totalSize,totalSize);
            S = full(A);
        end
    end
end




