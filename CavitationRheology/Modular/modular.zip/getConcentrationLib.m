classdef getConcentrationLib
    methods(Static)
         function [DYDT, ind_r_cavity] = velocity_bc_spline_porosity(t, Y, r, D_C, D_S, P, theta, r0, a, numr, Q_needle, cavity_radius_spline, ff_helper, v_helper, dvdr_helper)
            % HERE WE SOLVE FOR THE STRAIN LAMBDA AND THE CONCENTRATION
            % SIMULTANEOUSLY
            dr = r(2)-r(1);
            dYdt = zeros(length(r),size(Y,2));
            dYdr = zeros(length(r),size(Y,2));
            d2Ydr2 = zeros(length(r),size(Y,2));
                        
            cavity_radius = ppval(cavity_radius_spline,t);
            
            ind_r_cavity = ff_helper.binarySearchBin(r,cavity_radius);
            if (ind_r_cavity == -1)
                ind_r_cavity = numel(r);
            end
          
            v = v_helper.ethanol_velocity_porosity(r, ind_r_cavity, r0, theta, Q_needle);
            dvdr = dvdr_helper.simple_velocity_gradient_porosity(r, ind_r_cavity, theta, Q_needle);
            
            %Concentration at cavity/stroma interface
            C_intf_CSa = (D_C.*Y(ind_r_cavity)+(D_S.*Y(ind_r_cavity+1)))./((D_S.*P)+D_C); %Right before interface
            C_intf_CSb = (D_C.*Y(ind_r_cavity)+(D_S.*Y(ind_r_cavity+1)))./((D_C./P)+D_S); %Right after interface
            
            for i = 1 %y direction BC zero flux (dcdx=0)
                dYdt(i,:) = 6*D_C.*(Y(i+1,:)-Y(i,:))./(dr.^2);
            end
            for i = 2:ind_r_cavity-1 %inside cavity
                dYdr(i,:) = (Y(i,:)-Y(i-1,:))./dr; %backward difference
                %dCdr(i,:) = (C(i+1,:)-C(i-1,:))./(2*dr); %central difference
                %dCdr(i,:) = (C(i+1,:)-C(i,:))./dr; %forward difference
                d2Ydr2(i,:) = (Y(i+1,:)-2.*Y(i,:)+Y(i-1,:))./(dr.^2);
                dYdt(i,:) = ((2*D_C/r(i)).*dYdr(i,:))+(D_C*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = ind_r_cavity %right before interface - cavity/stroma
               dYdr(i,:) = (Y(i,:)-Y(i-1,:))./dr; %backward difference
               %dCdr(i,:) = (C_intf_CSa-C(i-1,:))./(2*dr); %central difference
               %dCdr(i,:) = (C_intf_CSa-C(i,:))./dr; %forward difference
               d2Ydr2(i,:) = (Y(i-1,:)-2.*Y(i,:)+C_intf_CSa)./(dr.^2);
               dYdt(i,:) = ((2*D_C/r(i)).*dYdr(i,:))+(D_C*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = (ind_r_cavity+1) %right after interface - cavity/stroma
                dYdr(i,:) = (Y(i,:)-C_intf_CSb)./dr; %backward difference
                %dCdr(i,:) = (C(i+1,:)-C_intf_CSb)./(2*dr); %central difference
                %dCdr(i,:) = (C(i+1,:)-C(i,:))./dr; %forward diffe~rence
                d2Ydr2(i,:) = ((C_intf_CSb)-2.*Y(i,:)+Y(i+1,:))./(dr.^2);
                dYdt(i,:) = ((2*D_S/r(i)).*dYdr(i,:))+(D_S*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = ind_r_cavity+2:(numr-1) %in stroma
                %dCdr(i) = (C(i)-C(i-1))./dr; %backward difference
                dYdr(i,:) = (Y(i+1,:)-Y(i-1,:))./(2*dr); %central difference
                %dCdr(i,:) = (C(i+1,:)-C(i,:))./dr; %forward difference
                d2Ydr2(i,:) = (Y(i+1,:)-2.*Y(i,:)+Y(i-1,:))./(dr.^2);
                dYdt(i,:) = ((2*D_S/r(i)).*dYdr(i,:))+(D_S*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = numr %end of stroma, B.C.
                %dCdt(i,:) = 6*D_S*(C(i-1,:)-C(i,:))./(dr.^2);
                dYdt(i,:) = D_S*(Y(i,:)-2.*Y(i-1,:)+Y(i-2,:))./(dr.^2)-(2/a)*v(i)*Y(i);

                %dCdt(i,:) = 2*D_S*(C(i-1,:)-C(i,:))./(dr.^2);
            end

            DYDT = dYdt;
        end
        function [DYDT] = velocity_bc_spline(t, Y, r, D_C, D_S, phi, a, numr, v, dvdr, cavity_radius_spline, helper)
            % HERE WE SOLVE FOR THE STRAIN LAMBDA AND THE CONCENTRATION
            % SIMULTANEOUSLY
            dr = r(2)-r(1);
            dYdt = zeros(length(r),size(Y,2));
            dYdr = zeros(length(r),size(Y,2));
            d2Ydr2 = zeros(length(r),size(Y,2));
            
            % cavity_radius_t = spline(tvec, cavity_radius, t);
            
            cavity_radius = ppval(cavity_radius_spline,t);
            
            ind_r_cavity = helper.binarySearchBin(r,cavity_radius);
            if (ind_r_cavity == -1)
                ind_r_cavity = numel(r);
            end     

          
%             for i = 1 % here we solve for the strain
%                 dYdt(i,:) = Q_needle*(1-omega)./(4*pi*(r0^3)*(Y(i,:).^2));
%             end
%            
%             cavity_radius = dYdt(1,:) * r0;
% 
%             ind_r_cavity = helper.binarySearchBin(r,cavity_radius(end));
%             if (ind_r_cavity == -1)
%                 ind_r_cavity = numel(r);
%             end
%             ind_Y_r_cavity = ind_r_cavity+1;
            
            %Concentration at cavity/stroma interface
            C_intf_CSa = (D_C.*Y(ind_r_cavity)+(D_S.*Y(ind_r_cavity+1)))./((D_S.*phi)+D_C); %Right before interface
            C_intf_CSb = (D_C.*Y(ind_r_cavity)+(D_S.*Y(ind_r_cavity+1)))./((D_C./phi)+D_S); %Right after interface
            
            for i = 1 %y direction BC zero flux (dcdx=0)
                dYdt(i,:) = 6*D_C.*(Y(i+1,:)-Y(i,:))./(dr.^2);
            end
            for i = 2:ind_r_cavity-1 %inside cavity
                dYdr(i,:) = (Y(i,:)-Y(i-1,:))./dr; %backward difference
                %dCdr(i,:) = (C(i+1,:)-C(i-1,:))./(2*dr); %central difference
                %dCdr(i,:) = (C(i+1,:)-C(i,:))./dr; %forward difference
                d2Ydr2(i,:) = (Y(i+1,:)-2.*Y(i,:)+Y(i-1,:))./(dr.^2);
                dYdt(i,:) = ((2*D_C/r(i)).*dYdr(i,:))+(D_C*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = ind_r_cavity %right before interface - cavity/stroma
               dYdr(i,:) = (Y(i,:)-Y(i-1,:))./dr; %backward difference
               %dCdr(i,:) = (C_intf_CSa-C(i-1,:))./(2*dr); %central difference
               %dCdr(i,:) = (C_intf_CSa-C(i,:))./dr; %forward difference
               d2Ydr2(i,:) = (Y(i-1,:)-2.*Y(i,:)+C_intf_CSa)./(dr.^2);
               dYdt(i,:) = ((2*D_C/r(i)).*dYdr(i,:))+(D_C*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = (ind_r_cavity+1) %right after interface - cavity/stroma
                dYdr(i,:) = (Y(i,:)-C_intf_CSb)./dr; %backward difference
                %dCdr(i,:) = (C(i+1,:)-C_intf_CSb)./(2*dr); %central difference
                %dCdr(i,:) = (C(i+1,:)-C(i,:))./dr; %forward diffe~rence
                d2Ydr2(i,:) = ((C_intf_CSb)-2.*Y(i,:)+Y(i+1,:))./(dr.^2);
                dYdt(i,:) = ((2*D_S/r(i)).*dYdr(i,:))+(D_S*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = ind_r_cavity+2:(numr-1) %in stroma
                %dCdr(i) = (C(i)-C(i-1))./dr; %backward difference
                dYdr(i,:) = (Y(i+1,:)-Y(i-1,:))./(2*dr); %central difference
                %dCdr(i,:) = (C(i+1,:)-C(i,:))./dr; %forward difference
                d2Ydr2(i,:) = (Y(i+1,:)-2.*Y(i,:)+Y(i-1,:))./(dr.^2);
                dYdt(i,:) = ((2*D_S/r(i)).*dYdr(i,:))+(D_S*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = numr %end of stroma, B.C.
                %dCdt(i,:) = 6*D_S*(C(i-1,:)-C(i,:))./(dr.^2);
                dYdt(i,:) = D_S*(Y(i,:)-2.*Y(i-1,:)+Y(i-2,:))./(dr.^2)-(2/a)*v(i)*Y(i);

                %dCdt(i,:) = 2*D_S*(C(i-1,:)-C(i,:))./(dr.^2);
            end

            DYDT = dYdt;
        end
        function [DYDT] = velocity_bc(t, Y, r, omega, Q_needle, r0, D_C, D_S, phi, a, numr, v, dvdr, helper)
            % HERE WE SOLVE FOR THE STRAIN LAMBDA AND THE CONCENTRATION
            % SIMULTANEOUSLY
            dr = r(2)-r(1);
            dYdt = zeros(length(r)+1,size(Y,2));
            dYdr = zeros(length(r)+1,size(Y,2));
            d2Ydr2 = zeros(length(r)+1,size(Y,2));
            
          
            for i = 1 % here we solve for the strain
                dYdt(i,:) = Q_needle*(1-omega)./(4*pi*(r0^3)*(Y(i,:).^2));
            end
           
            cavity_radius = dYdt(1,:) * r0;

            ind_r_cavity = helper.binarySearchBin(r,cavity_radius(end));
            if (ind_r_cavity == -1)
                ind_r_cavity = numel(r);
            end
            ind_Y_r_cavity = ind_r_cavity+1;
            
            %Concentration at cavity/stroma interface
            C_intf_CSa = (D_C.*Y(ind_Y_r_cavity)+(D_S.*Y(ind_Y_r_cavity+1)))./((D_S.*phi)+D_C); %Right before interface
            C_intf_CSb = (D_C.*Y(ind_Y_r_cavity)+(D_S.*Y(ind_Y_r_cavity+1)))./((D_C./phi)+D_S); %Right after interface
            
            for i = 2 %y direction BC zero flux (dcdx=0)
                dYdt(i,:) = 6*D_C.*(Y(i+1,:)-Y(i,:))./(dr.^2);
            end
            for i = 3:ind_Y_r_cavity-1 %inside cavity
                dYdr(i,:) = (Y(i,:)-Y(i-1,:))./dr; %backward difference
                %dCdr(i,:) = (C(i+1,:)-C(i-1,:))./(2*dr); %central difference
                %dCdr(i,:) = (C(i+1,:)-C(i,:))./dr; %forward difference
                d2Ydr2(i,:) = (Y(i+1,:)-2.*Y(i,:)+Y(i-1,:))./(dr.^2);
                dYdt(i,:) = ((2*D_C/r(i)).*dYdr(i,:))+(D_C*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = ind_Y_r_cavity %right before interface - cavity/stroma
               dYdr(i,:) = (Y(i,:)-Y(i-1,:))./dr; %backward difference
               %dCdr(i,:) = (C_intf_CSa-C(i-1,:))./(2*dr); %central difference
               %dCdr(i,:) = (C_intf_CSa-C(i,:))./dr; %forward difference
               d2Ydr2(i,:) = (Y(i-1,:)-2.*Y(i,:)+C_intf_CSa)./(dr.^2);
               dYdt(i,:) = ((2*D_C/r(i)).*dYdr(i,:))+(D_C*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = (ind_Y_r_cavity+1) %right after interface - cavity/stroma
                dYdr(i,:) = (Y(i,:)-C_intf_CSb)./dr; %backward difference
                %dCdr(i,:) = (C(i+1,:)-C_intf_CSb)./(2*dr); %central difference
                %dCdr(i,:) = (C(i+1,:)-C(i,:))./dr; %forward difference
                d2Ydr2(i,:) = ((C_intf_CSb)-2.*Y(i,:)+Y(i+1,:))./(dr.^2);
                dYdt(i,:) = ((2*D_S/r(i)).*dYdr(i,:))+(D_S*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = ind_Y_r_cavity+2:(numr-1) %in stroma
                %dCdr(i) = (C(i)-C(i-1))./dr; %backward difference
                dYdr(i,:) = (Y(i+1,:)-Y(i-1,:))./(2*dr); %central difference
                %dCdr(i,:) = (C(i+1,:)-C(i,:))./dr; %forward difference
                d2Ydr2(i,:) = (Y(i+1,:)-2.*Y(i,:)+Y(i-1,:))./(dr.^2);
                dYdt(i,:) = ((2*D_S/r(i)).*dYdr(i,:))+(D_S*d2Ydr2(i,:))-((2/r(i)).*(v(i).*Y(i,:)))-(Y(i,:).*dvdr(i))-(v(i).*dYdr(i,:));
            end
            for i = numr %end of stroma, B.C.
                %dCdt(i,:) = 6*D_S*(C(i-1,:)-C(i,:))./(dr.^2);
                dYdt(i,:) = D_S*(Y(i,:)-2.*Y(i-1,:)+Y(i-2,:))./(dr.^2)-(2/a)*v(i)*Y(i);

                %dCdt(i,:) = 2*D_S*(C(i-1,:)-C(i,:))./(dr.^2);
            end

            DYDT = dYdt;
        end
    end
end
