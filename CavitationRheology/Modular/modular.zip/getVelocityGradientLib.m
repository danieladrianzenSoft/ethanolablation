classdef getVelocityGradientLib
    methods(Static)
        function dvdr = simple_velocity_gradient_porosity(r, ind_r_cavity, theta, Q_needle)
            % simplified. Analytically, velocity simplifies to Q / (4pi
            % r^2)
%             dvdr = zeros(length(r),1);
%             dvdr(1:ind_r0) = 0;
%             dvdr(ind_r0+1:end) = - Q_needle ./ (2 * pi * r(ind_r0+1:end).^3);
            dvdr = zeros(length(r),1);
            dvdr(1) = 0;
            dvdr(2:ind_r_cavity) = - Q_needle ./ (2 * pi * (r(2 : ind_r_cavity).^3));
            dvdr(ind_r_cavity+1:end) = - (Q_needle * theta)./ (2 * pi * (r(ind_r_cavity + 1 : end).^3));

        end
        function dvdr = simple_velocity_gradient(r, ind_r0, r0, Q_needle)
            % simplified. Analytically, velocity simplifies to Q / (4pi
            % r^2)
%             dvdr = zeros(length(r),1);
%             dvdr(1:ind_r0) = 0;
%             dvdr(ind_r0+1:end) = - Q_needle ./ (2 * pi * r(ind_r0+1:end).^3);
              dvdr = zeros(length(r),1);
              dvdr(1) = 0;
              dvdr(2:end) = - Q_needle ./ (2 * pi * r(2:end).^3);
        end
    end
end

