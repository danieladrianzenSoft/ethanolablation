%Ethanol + Ethyl Cellulose
[t2_1,PsurfaceC_1,tm_1,MsurfaceC_1,R2_1,D_S1] = twoCompartment_Ethanol011619();
%Ethanol alone
[t2_2,PsurfaceC_2,tm_2,MsurfaceC_2,R2_2,D_S2] = twoCompartment_Ethanol112018();

%PsurfaceC_2 = PsurfaceC_2/(max(PsurfaceC_1));
%MsurfaceC_2 = MsurfaceC_2/(max(MsurfaceC_1));

figure()
p1 = plot(t2_1/60,PsurfaceC_1,'color',[176,36,24]/255,'LineWidth',2);
hold on
plot(tm_1,MsurfaceC_1,'x','color',[176,36,24]/255)
p2 = plot(t2_2/60,PsurfaceC_2,'LineWidth',2,'color',[5,49,245]/255);
hold on
plot(tm_2,MsurfaceC_2,'x','color',[5,49,245]/255)
%plot(TTemp,ConcTemp,'ro')
legend([p1,p2],'6% EECF','Ethanol Alone')
xlabel('Time (mins)','FontSize',20,'FontWeight','Bold')
ylabel('Ethanol Concentration (normalized)','FontSize',20,'FontWeight','Bold')
%title('Ethanol concentration vs time on tumor surface','FontSize',18,'FontWeight','Bold')
XT = get(gca,'XTick');
set(gca,'FontSize',16)
YT = get(gca,'YTick');
set(gca,'FontSize',16)

D_S1
R2_1
D_S2
R2_2
